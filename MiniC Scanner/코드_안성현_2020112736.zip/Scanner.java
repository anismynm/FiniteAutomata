import java.io.*;

public class Scanner {

    // 클래스 변수
    private boolean isEof = false;           // 파일의 끝에 도달했는지 여부를 나타내는 플래그
    private boolean isError = false;         // 현재 에러 처리를 하였는지 여부를 나타내는 플래그
    private char ch = ' ';                   // 현재 처리 중인 문자
    private BufferedReader input;            // 입력 파일을 읽기 위한 BufferedReader
    private String line = "";                // 현재 처리 중인 라인
    private int lineno = 0;                  // line num
    private int col = 1;                     // column num
    private final String letters = "abcdefghijklmnopqrstuvwxyz" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private final String digits = "0123456789";
    private final char eolnCh = '\n';        // end of line char
    private final char eofCh = '\004';       // end of file char

    public Scanner (String fileName) {       // source filename
        String file = "/Users/anismynm/Desktop/과제/2024-1/형식언어/과제/FormalLanguages-master/MiniC Examples"; // 디렉토리 경로
        System.out.println("Begin scanning... programs" + fileName + "\n"); // 스캐닝이 시작되었음을 사용자에게 알림
        try {
            input = new BufferedReader (new FileReader(file + fileName)); // 입력 파일을 읽기 위한 BufferedReader 초기화
        }
        catch (FileNotFoundException e) {    // 파일을 찾을 수 없는 경우 처리
            System.out.println("File not found: " + fileName); // 오류 메시지 출력
            System.exit(1); // 오류 코드로 프로그램 종료 (종료하지 않고 다음 토큰을 읽어야 하므로 주석처리 함)
        }
    }

    private char nextChar() { // Return next char
        if (ch == eofCh) // 파일의 끝에 도달했는지 확인
            error("Attempt to read past end of file"); // 그렇다면 오류 발생
        col++; // 열 번호 증가
        if (col >= line.length()) { // 열 번호가 라인 길이를 초과하는 경우
            try {
                line = input.readLine( ); // 다음 라인을 읽음
            } catch (IOException e) {
                System.err.println(e); // IO 예외 출력
                System.exit(1); // 오류 코드로 프로그램 종료
            } // try
            if (line == null) // at end of file
                line = "" + eofCh; // 라인을 파일 끝 문자로 설정
            else {
                // System.out.println(lineno + ":\t" + line);
                lineno++; // 라인 번호 증가
                line += eolnCh; // 라인에 줄 바꿈 문자 추가
            } // if line
            col = 0; // 열 번호 재설정
        } // if col
        return line.charAt(col); // 다음 문자 반환
    }

    public Token next( ) { // return next token
        do {
            if (isError) {
                isError = false;
                ch = nextChar();
                return null;
            }
            if (isLetter(ch) || ch == '_') { // ident or keyword
                String spelling = concat(letters + digits + '_'); // 문자, 숫자, 밑줄을 연결
                return Token.keyword(spelling); // 키워드 토큰 반환
            } else if (isDigit(ch) || ch == '.') { // int, double literal
                String number = concat(digits + '.' + 'e' + '+' + '-'); // 숫자를 연결 (소수점, 숏폼 포함)
                // 정수, 소수에 따라 정수 리터럴, 소수 리터럴 토큰 반환
                if (number.contains(".")) {
                    return Token.mkDoubleLiteral(number); // double 리터럴 토큰 반환
                }
                else {
                    return Token.mkIntLiteral(number); // 정수 리터럴 토큰 반환
                }
            } else switch (ch) {
                case ' ': case '\t': case '\r': case eolnCh: // 공백 문자 처리
                    ch = nextChar(); // 다음 문자 가져오기
                    break;

                case '/':  // divide or divAssign or comment
                    ch = nextChar(); // 다음 문자 가져오기
                    if (ch == '=')  { // divAssign
                        ch = nextChar(); // 다음 문자 가져오기
                        return Token.divAssignTok; // 나누기 할당 토큰 반환
                    }

                    // divide
                    if (ch != '*' && ch != '/') return Token.divideTok; // 다음 문자가 '*' 또는 '/'가 아닌 경우 나누기 토큰 반환

                    // multi line comment
                    if (ch == '*') { // 다음 문자가 '*'인 경우
                        do {
                            while (ch != '*') ch = nextChar(); // '*'이 나올 때까지 반복
                            ch = nextChar(); // 다음 문자 가져오기
                        } while (ch != '/'); // 주석의 끝까지 반복
                        ch = nextChar(); // 다음 문자 가져오기
                    }
                    // single line comment
                    else if (ch == '/')  {
                        // 한 줄 주석 처리
                        do {
                            ch = nextChar(); // 다음 문자 가져오기
                        } while (ch != eolnCh); // 줄 끝까지 반복
                        ch = nextChar(); // 다음 문자 가져오기
                    }

                    break;

                case '\'':  // char literal
                    char ch1 = nextChar(); // 따옴표 속 char 가져오기
                    nextChar(); // get '
                    ch = nextChar(); // get ;
                    return Token.mkCharLiteral("" + ch1); // char string 형태로 만들어 char 리터럴 토큰 반환

                case '\"': // string literal
                    String str = concat(); // string 연결
                    ch = nextChar(); // get ;
                    return Token.mkStringLiteral(str); // string 리터럴 토큰 반환

                // 기타 연산자 및 기호 처리
                case eofCh: return Token.eofTok; // 파일 끝 문자 처리

                case '+':
                    ch = nextChar(); // 다음 문자 가져오기
                    if (ch == '=')  { // addAssign
                        ch = nextChar(); // 다음 문자 가져오기
                        return Token.addAssignTok; // 더하기 할당 토큰 반환
                    }
                    else if (ch == '+')  { // increment
                        ch = nextChar(); // 다음 문자 가져오기
                        return Token.incrementTok; // 증가 토큰 반환
                    }
                    return Token.plusTok; // 더하기 연산자 토큰 반환

                // 비슷한 방식으로 다른 연산자 및 기호 처리
                case '-':
                    ch = nextChar();
                    if (ch == '=')  { // subAssign
                        ch = nextChar();
                        return Token.subAssignTok;
                    }
                    else if (ch == '-')  { // decrement
                        ch = nextChar();
                        return Token.decrementTok;
                    }
                    return Token.minusTok;

                case '*':
                    ch = nextChar();
                    if (ch == '=')  { // multAssign
                        ch = nextChar();
                        return Token.multAssignTok;
                    }
                    return Token.multiplyTok;

                case '%':
                    ch = nextChar();
                    if (ch == '=')  {  // remAssign
                        ch = nextChar();
                        return Token.remAssignTok;
                    }
                    return Token.reminderTok;

                case '(': ch = nextChar();
                    return Token.leftParenTok;

                case ')': ch = nextChar();
                    return Token.rightParenTok;

                case '{': ch = nextChar();
                    return Token.leftBraceTok;

                case '}': ch = nextChar();
                    return Token.rightBraceTok;

                // 추가
                case ':': ch = nextChar();
                    return Token.colonTok; // case, default 뒤 ':' 토큰 반환

                case ';': ch = nextChar();
                    return Token.semicolonTok;

                case ',': ch = nextChar();
                    return Token.commaTok;

                case '&': check('&'); return Token.andTok;
                case '|': check('|'); return Token.orTok;

                case '=':
                    return chkOpt('=', Token.assignTok,
                            Token.eqeqTok);

                case '<':
                    return chkOpt('=', Token.ltTok,
                            Token.lteqTok);
                case '>':
                    return chkOpt('=', Token.gtTok,
                            Token.gteqTok);
                case '!':
                    return chkOpt('=', Token.notTok,
                            Token.noteqTok);

                default:
                    error("Illegal character '" + ch + "'"); // 잘못된 문자 처리
                    isError = true;
                    break;
            } // switch
        } while (true);
    } // next


    // 문자가 문자인지 확인하는 메서드
    private boolean isLetter(char c) {
        return (c>='a' && c<='z' || c>='A' && c<='Z');
    }

    // 문자가 숫자인지 확인하는 메서드
    private boolean isDigit(char c) {
        return (c>='0' && c<='9');
    }

    // 문자가 예상한 문자와 일치하는지 확인하는 메서드
    private void check(char c) {
        ch = nextChar(); // 다음 문자 가져오기
        if (ch != c)
            error("Illegal character, expecting " + c); // 문자가 일치하지 않으면 오류 발생
        ch = nextChar(); // 다음 문자 가져오기
    }

    // 선택적 토큰을 확인하는 메서드
    private Token chkOpt(char c, Token one, Token two) {
        ch = nextChar(); // 다음 문자 가져오기
        if (ch != c)
            return one; // 문자가 일치하지 않으면 첫 번째 토큰 반환
        ch = nextChar(); // 다음 문자 가져오기
        return two; // 문자가 일치하면 두 번째 토큰 반환
    }

    // 지정된 집합에서 문자를 연결하는 메서드
    private String concat(String set) {
        String r = ""; // 결과 문자열 초기화
        do {
            r += ch; // 현재 문자를 결과 문자열에 추가
            ch = nextChar(); // 다음 문자 가져오기
        } while (set.indexOf(ch) >= 0); // 문자가 지정된 집합에 있는 동안 반복
        return r; // 연결된 문자열 반환
    }

    // 문자열 생성 메서드 (string 리터럴 전용)
    private String concat() {
        StringBuilder r = new StringBuilder();
        while (true) {
            ch = nextChar();
            if (ch == '\"') {
                break;
            }
            if (ch == '\\') {
                ch = nextChar();
                switch (ch) {
                    case 'n':
                        r.append('\n');
                        break;

                    case 't':
                        r.append('\t');
                        break;

                    case 'b':
                        r.append('\b');
                        break;

                    case '\\':
                        r.append('\\');
                        break;

                    case '\'':
                        r.append('\'');
                        break;

                    case '\"':
                        r.append('\"');
                        break;

                    default:
                        break;
                }
            }
            else {
                r.append(ch);
            }
        } // " 가 나올 때 까지 문자열 가져와서 r에 추가
        return r.toString(); // 연결된 문자열 반환
    }

    // 오류 처리를 위한 메서드
    public void error (String msg) {
        System.err.print(line); // 현재 라인 출력
        System.err.println("Error: column " + col + " " + msg + "\n"); // 열 번호와 오류 메시지 출력
        // System.exit(1); // 오류 코드로 프로그램 종료
    }

    // 메인 메서드
    static public void main ( String[] argv ) {
        Scanner lexer = new Scanner("/extend.mc"); // Scanner 객체 생성
        Token tok = lexer.next( ); // 다음 토큰 가져오기
        while (tok != Token.eofTok) { // 파일 끝 토큰을 만날 때까지 반복
            if (tok != null) { // error 문구를 출력했을 땐 token이 null을 출력 -> 토큰 출력 안하고 바로 다음으로
                System.out.println(tok.toString()); // 토큰 출력
            }
            tok = lexer.next( ); // 다음 토큰 가져오기
        }
    } // main
}